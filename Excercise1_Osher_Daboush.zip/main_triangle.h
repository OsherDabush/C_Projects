void triangle1(int n, char ch);
void triangle2(int n, char ch);
void triangle3(int n, char ch);
void triangle4(int n, char ch);
void triangle5(int n, char ch);
void triangle6(int n, char ch);

